create view view_west_team as
select `springboot`.`team`.`id`           AS `id`,
       `springboot`.`team`.`team_id`      AS `team_id`,
       `springboot`.`team`.`team_name_en` AS `team_name_en`,
       `springboot`.`team`.`team_name_ch` AS `team_name_ch`,
       `springboot`.`team`.`zone`         AS `zone`,
       `springboot`.`team`.`victory`      AS `victory`,
       `springboot`.`team`.`defeat`       AS `defeat`,
       `springboot`.`team`.`ranking`      AS `ranking`
from `springboot`.`team`
where (`springboot`.`team`.`zone` = 1);

